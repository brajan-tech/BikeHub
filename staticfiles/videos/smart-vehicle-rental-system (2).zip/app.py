import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, timedelta
import secrets

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'smart_vehicle_secret_key_' + secrets.token_hex(16))

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# File upload configuration
UPLOAD_FOLDER = 'static/uploads/licenses'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Models
class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(15))
    is_admin = db.Column(db.Boolean, default=False)
    license_url = db.Column(db.String(255))
    license_verified = db.Column(db.Boolean, default=False)
    loyalty_points = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Vehicle(db.Model):
    __tablename__ = 'vehicles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    brand = db.Column(db.String(50), nullable=False)
    type = db.Column(db.String(20), nullable=False) # car or bike
    hourly_rate = db.Column(db.Float, nullable=False)
    daily_rate = db.Column(db.Float, nullable=False)
    fuel_type = db.Column(db.String(20), default='Petrol')
    seating_capacity = db.Column(db.Integer, default=2)
    current_km = db.Column(db.Integer, default=0)
    last_service_km = db.Column(db.Integer, default=0)
    current_fuel_level = db.Column(db.Integer, default=100)
    status = db.Column(db.String(50), default='Available')
    image_url = db.Column(db.String(255))
    features = db.Column(db.Text)

class Booking(db.Model):
    __tablename__ = 'bookings'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    vehicle_id = db.Column(db.Integer, db.ForeignKey('vehicles.id'))
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)
    rental_type = db.Column(db.String(20))
    total_price = db.Column(db.Float)
    discount_applied = db.Column(db.Float, default=0)
    initial_fuel = db.Column(db.Integer)
    returned_fuel = db.Column(db.Integer)
    fuel_fine = db.Column(db.Float, default=0)
    km_driven = db.Column(db.Integer, default=0)
    status = db.Column(db.String(50), default='Pending')
    payment_status = db.Column(db.String(50), default='Pending')
    razorpay_order_id = db.Column(db.String(100))
    razorpay_payment_id = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('bookings', lazy=True))
    vehicle = db.relationship('Vehicle', backref=db.backref('bookings', lazy=True))

class SOSRequest(db.Model):
    __tablename__ = 'sos_requests'
    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.Integer, db.ForeignKey('bookings.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    location_lat = db.Column(db.Float)
    location_lng = db.Column(db.Float)
    issue_description = db.Column(db.Text)
    status = db.Column(db.String(30), default='Open')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Helper: Calculate rental price with loyalty discount
def calculate_rental_price(vehicle, start, end, loyalty_points):
    duration = end - start
    hours = duration.total_seconds() / 3600
    
    if hours < 24:
        price = hours * vehicle.hourly_rate
        rental_type = 'hourly'
    else:
        days = hours / 24
        price = days * vehicle.daily_rate
        rental_type = 'daily'
    
    discount = 0
    if loyalty_points >= 100:
        discount = price * 0.1
        price -= discount
        
    return round(price, 2), discount, rental_type

# Helper: Check service reminder
def check_service_reminder(vehicle_id):
    vehicle = Vehicle.query.get(vehicle_id)
    if vehicle and (vehicle.current_km - vehicle.last_service_km > 1000):
        vehicle.status = 'Maintenance Required'
        db.session.commit()

# Helper: AI Vehicle Recommendation
def ai_recommend_vehicle(budget, distance):
    vehicles = Vehicle.query.filter_by(status='Available').filter(Vehicle.daily_rate <= budget).order_by(Vehicle.daily_rate.asc()).all()
    
    if not vehicles:
        return None
    
    if distance < 20 and budget < 1500:
        bikes = [v for v in vehicles if v.type == 'bike']
        return bikes[0] if bikes else vehicles[0]
    elif distance > 100:
        cars = [v for v in vehicles if v.type == 'car']
        return cars[0] if cars else vehicles[0]
    else:
        return vehicles[0]

# Route: Home page with vehicle listings
@app.route('/')
def index():
    vehicles = Vehicle.query.order_by(Vehicle.type, Vehicle.name).all()
    for v in vehicles:
        check_service_reminder(v.id)
    
    user = User.query.get(session['user_id']) if 'user_id' in session else None
    return render_template('index.html', vehicles=vehicles, user=user)

# Route: User Registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        hashed_pw = generate_password_hash(request.form['password'])
        new_user = User(
            username=request.form['username'],
            email=request.form['email'],
            phone=request.form.get('phone'),
            password_hash=hashed_pw
        )
        db.session.add(new_user)
        try:
            db.session.commit()
            flash('Registration successful!', 'success')
            return redirect(url_for('login'))
        except:
            flash('User already exists!', 'danger')
    return render_template('register.html')

# Route: User Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password_hash, request.form['password']):
            session['user_id'] = user.id
            session['is_admin'] = user.is_admin
            return redirect(url_for('admin_dashboard' if user.is_admin else 'index'))
        flash('Invalid Credentials', 'danger')
    return render_template('login.html')

# Route: Logout
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# Route: User Profile
@app.route('/profile')
def profile():
    if 'user_id' not in session:
        flash('Please login first!', 'warning')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    bookings = Booking.query.filter_by(user_id=user.id).join(Vehicle).order_by(Booking.created_at.desc()).all()
    
    return render_template('profile.html', user=user, bookings=bookings)

# Route: Upload Driver License
@app.route('/upload_license', methods=['POST'])
def upload_license():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if 'license' not in request.files:
        flash('No file selected!', 'danger')
        return redirect(url_for('profile'))
    
    file = request.files['license']
    
    if file.filename == '':
        flash('No file selected!', 'danger')
        return redirect(url_for('profile'))
    
    filename = secure_filename(f"user_{session['user_id']}_{file.filename}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    user = User.query.get(session['user_id'])
    user.license_url = filepath
    db.session.commit()
    
    flash('License uploaded successfully! Waiting for admin verification.', 'success')
    return redirect(url_for('profile'))

# Route: AI Recommendation
@app.route('/recommend', methods=['POST'])
def recommend_vehicle():
    budget = float(request.form.get('budget', 0))
    distance = float(request.form.get('distance', 0))
    
    recommended = ai_recommend_vehicle(budget, distance)
    
    if recommended:
        return jsonify({
            'success': True,
            'vehicle': {
                'id': recommended.id,
                'name': recommended.name,
                'brand': recommended.brand,
                'type': recommended.type,
                'hourly_rate': recommended.hourly_rate,
                'daily_rate': recommended.daily_rate,
                'fuel_type': recommended.fuel_type,
                'seating_capacity': recommended.seating_capacity,
                'current_km': recommended.current_km,
                'last_service_km': recommended.last_service_km,
                'current_fuel_level': recommended.current_fuel_level,
                'status': recommended.status,
                'image_url': recommended.image_url,
                'features': recommended.features
            }
        })
    else:
        return jsonify({
            'success': False,
            'message': 'No vehicles found within your budget!'
        })

# Route: Check vehicle availability
@app.route('/check_availability/<int:vehicle_id>')
def check_availability(vehicle_id):
    start_str = request.args.get('start')
    end_str = request.args.get('end')
    
    if not start_str or not end_str:
        return jsonify({'available': True})
    
    try:
        start = datetime.fromisoformat(start_str)
        end = datetime.fromisoformat(end_str)
    except:
        return jsonify({'available': True})
    
    overlap = Booking.query.filter_by(vehicle_id=vehicle_id).filter(
        Booking.status.in_(['Pending', 'Paid', 'Active']),
        Booking.start_time < end, Booking.end_time > start
    ).first()
    
    return jsonify({'available': overlap is None})

# Route: Book Vehicle
@app.route('/book/<int:vehicle_id>', methods=['GET', 'POST'])
def book_vehicle(vehicle_id):
    if 'user_id' not in session:
        flash('Please login first!', 'warning')
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    
    if not user.license_verified:
        flash('License must be verified first!', 'warning')
        return redirect(url_for('profile'))
        
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    
    if request.method == 'POST':
        start = datetime.fromisoformat(request.form['start_time'])
        end = datetime.fromisoformat(request.form['end_time'])
        
        # Double booking check
        overlap = Booking.query.filter_by(vehicle_id=vehicle_id).filter(
            Booking.status.in_(['Pending', 'Paid']),
            Booking.start_time < end, Booking.end_time > start
        ).first()
        
        if overlap:
            flash('Vehicle already booked!', 'danger')
            return redirect(url_for('book_vehicle', vehicle_id=vehicle_id))
            
        price, discount, r_type = calculate_rental_price(vehicle, start, end, user.loyalty_points)
        
        new_booking = Booking(
            user_id=user.id, vehicle_id=vehicle_id, start_time=start, end_time=end,
            rental_type=r_type, total_price=price, discount_applied=discount,
            initial_fuel=vehicle.current_fuel_level, razorpay_order_id=f"order_{secrets.token_hex(8)}"
        )
        db.session.add(new_booking)
        db.session.commit()
        return redirect(url_for('payment_page', booking_id=new_booking.id))
        
    return render_template('booking.html', vehicle=vehicle, user=user)

# Route: Payment Page
@app.route('/payment/<int:booking_id>')
def payment_page(booking_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != session['user_id']:
        flash('Access denied!', 'danger')
        return redirect(url_for('index'))
    
    return render_template('payment.html', booking=booking)

# Route: Payment Success (Mock Razorpay Confirmation)
@app.route('/payment_success/<int:booking_id>', methods=['POST'])
def payment_success(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    booking.status = 'Paid'
    booking.payment_status = 'Completed'
    booking.user.loyalty_points += 10
    db.session.commit()
    flash('Booking Confirmed!', 'success')
    return redirect(url_for('profile'))

# Route: Return Vehicle
@app.route('/return_vehicle/<int:booking_id>', methods=['POST'])
def return_vehicle(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    ret_fuel = int(request.form['returned_fuel'])
    km = int(request.form['km_driven'])
    
    # Smart Fuel Logic: Fine ₹500 if less fuel
    fine = 500 if ret_fuel < booking.initial_fuel else 0
    if fine: flash(f'Fuel fine of ₹{fine} applied', 'warning')
    
    booking.returned_fuel = ret_fuel
    booking.km_driven = km
    booking.fuel_fine = fine
    booking.status = 'Completed'
    
    # Update vehicle
    booking.vehicle.current_km += km
    booking.vehicle.current_fuel_level = ret_fuel
    db.session.commit()
    
    check_service_reminder(booking.vehicle_id)
    return redirect(url_for('profile'))

# Route: SOS Request
@app.route('/sos/<int:booking_id>', methods=['POST'])
def sos_request(booking_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'})
    
    location_lat = request.form.get('latitude')
    location_lng = request.form.get('longitude')
    issue = request.form.get('issue', 'Emergency assistance required')
    
    new_sos_request = SOSRequest(
        booking_id=booking_id, user_id=session['user_id'], location_lat=location_lat,
        location_lng=location_lng, issue_description=issue
    )
    db.session.add(new_sos_request)
    db.session.commit()
    
    flash('SOS request sent! Admin will contact you shortly.', 'info')
    return jsonify({'success': True, 'message': 'SOS sent successfully'})

# Route: Admin Dashboard
@app.route('/admin')
def admin_dashboard():
    if not session.get('is_admin'):
        flash('Access denied! Admin only.', 'danger')
        return redirect(url_for('index'))
    
    total_users = User.query.filter_by(is_admin=False).count()
    total_vehicles = Vehicle.query.count()
    total_bookings = Booking.query.count()
    total_revenue = db.session.query(db.func.sum(Booking.total_price + Booking.fuel_fine)).filter_by(payment_status='Completed').scalar() or 0
    
    recent_bookings = Booking.query.join(Vehicle).join(User).order_by(Booking.created_at.desc()).limit(10).all()
    pending_licenses = User.query.filter(User.license_url.isnot(None), User.license_verified == False).order_by(User.created_at.desc()).all()
    sos_requests = SOSRequest.query.join(Booking).join(User).join(Vehicle).filter_by(status='Open').order_by(SOSRequest.created_at.desc()).all()
    
    return render_template('admin.html', 
                         total_users=total_users,
                         total_vehicles=total_vehicles,
                         total_bookings=total_bookings,
                         total_revenue=total_revenue,
                         recent_bookings=recent_bookings,
                         pending_licenses=pending_licenses,
                         sos_requests=sos_requests)

# Route: Verify User License
@app.route('/admin/verify_license/<int:user_id>')
def verify_license(user_id):
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    
    user = User.query.get_or_404(user_id)
    user.license_verified = True
    db.session.commit()
    
    flash('License verified successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

# Route: Manage Vehicles
@app.route('/admin/vehicles')
def admin_vehicles():
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    
    vehicles = Vehicle.query.order_by(Vehicle.type, Vehicle.name).all()
    
    return render_template('admin_vehicles.html', vehicles=vehicles)

# Route: Add Vehicle
@app.route('/admin/vehicles/add', methods=['POST'])
def add_vehicle():
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    
    new_vehicle = Vehicle(
        name=request.form['name'],
        brand=request.form['brand'],
        type=request.form['type'],
        hourly_rate=float(request.form['hourly_rate']),
        daily_rate=float(request.form['daily_rate']),
        fuel_type=request.form.get('fuel_type', 'Petrol'),
        seating_capacity=int(request.form.get('seating_capacity', 2)),
        features=request.form.get('features', '')
    )
    db.session.add(new_vehicle)
    db.session.commit()
    
    flash('Vehicle added successfully!', 'success')
    return redirect(url_for('admin_vehicles'))

# Route: Delete Vehicle
@app.route('/admin/vehicles/delete/<int:vehicle_id>')
def delete_vehicle(vehicle_id):
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    
    vehicle = Vehicle.query.get_or_404(vehicle_id)
    db.session.delete(vehicle)
    db.session.commit()
    
    flash('Vehicle deleted successfully!', 'success')
    return redirect(url_for('admin_vehicles'))

# Route: Resolve SOS
@app.route('/admin/sos/resolve/<int:sos_id>')
def resolve_sos(sos_id):
    if not session.get('is_admin'):
        return redirect(url_for('index'))
    
    sos_request = SOSRequest.query.get_or_404(sos_id)
    sos_request.status = 'Resolved'
    sos_request.resolved_at = datetime.utcnow()
    db.session.commit()
    
    flash('SOS request resolved!', 'success')
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    with app.app_context():
        # This will create tables if they don't exist based on the models
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
