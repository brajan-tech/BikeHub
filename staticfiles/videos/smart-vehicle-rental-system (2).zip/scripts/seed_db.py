import os
import psycopg2

DATABASE_URL = os.environ.get("DATABASE_URL")

def seed():
    if not DATABASE_URL:
        print("Error: DATABASE_URL not set in environment.")
        return

    try:
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        
        with open('scripts/schema_v1.sql', 'r') as f:
            sql_script = f.read()
            # Execute the entire script
            cur.execute(sql_script)
            
        conn.commit()
        cur.close()
        conn.close()
        print("Database seeded successfully!")
    except Exception as e:
        print(f"Error seeding database: {e}")

if __name__ == "__main__":
    seed()
