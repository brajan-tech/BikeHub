-- Drop tables if they exist
DROP TABLE IF EXISTS sos_requests;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS vehicles;
DROP TABLE IF EXISTS users;

-- Users Table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    is_admin BOOLEAN DEFAULT FALSE,
    license_url VARCHAR(255),
    license_verified BOOLEAN DEFAULT FALSE,
    loyalty_points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Vehicles Table
CREATE TABLE vehicles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    brand VARCHAR(50) NOT NULL,
    type VARCHAR(20) NOT NULL, -- car or bike
    hourly_rate FLOAT NOT NULL,
    daily_rate FLOAT NOT NULL,
    fuel_type VARCHAR(20) DEFAULT 'Petrol',
    seating_capacity INT DEFAULT 2,
    current_km INT DEFAULT 0,
    last_service_km INT DEFAULT 0,
    current_fuel_level INT DEFAULT 100,
    status VARCHAR(50) DEFAULT 'Available',
    image_url VARCHAR(255),
    features TEXT
);

-- Bookings Table
CREATE TABLE bookings (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id),
    vehicle_id INT REFERENCES vehicles(id),
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    rental_type VARCHAR(20),
    total_price FLOAT,
    discount_applied FLOAT DEFAULT 0,
    initial_fuel INT,
    returned_fuel INT,
    fuel_fine FLOAT DEFAULT 0,
    km_driven INT DEFAULT 0,
    status VARCHAR(50) DEFAULT 'Pending',
    payment_status VARCHAR(50) DEFAULT 'Pending',
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SOS Requests
CREATE TABLE sos_requests (
    id SERIAL PRIMARY KEY,
    booking_id INT REFERENCES bookings(id),
    user_id INT REFERENCES users(id),
    location_lat FLOAT,
    location_lng FLOAT,
    issue_description TEXT,
    status VARCHAR(30) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Initial Data
INSERT INTO vehicles (name, brand, type, hourly_rate, daily_rate, current_km, last_service_km, status, image_url, fuel_type, seating_capacity) 
VALUES 
('Tesla Model 3', 'Tesla', 'car', 500, 5000, 5000, 4800, 'Available', 'https://images.unsplash.com/photo-1560958089-b8a1929cea89?auto=format&fit=crop&w=800&q=80', 'Electric', 5),
('Royal Enfield Himalayan', 'Royal Enfield', 'bike', 100, 1000, 2000, 1500, 'Available', 'https://images.unsplash.com/photo-1558981403-c5f91dbbe9ad?auto=format&fit=crop&w=800&q=80', 'Petrol', 2),
('Hyundai Creta', 'Hyundai', 'car', 300, 2500, 8000, 7500, 'Available', 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80', 'Diesel', 5);
