import os
from app import db, app, User, Vehicle
from werkzeug.security import generate_password_hash

def seed_data():
    with app.app_context():
        # Clear existing
        db.drop_all()
        db.create_all()

        # Create Admin
        admin = User(
            username='admin',
            email='admin@smartrental.com',
            password_hash=generate_password_hash('admin123'),
            is_admin=True,
            license_verified=True
        )
        db.session.add(admin)

        # Add Vehicles
        vehicles = [
            Vehicle(name='Tesla Model 3', type='car', hourly_rate=500, daily_rate=5000, current_km=5000, last_service_km=4800),
            Vehicle(name='Royal Enfield Himalayan', type='bike', hourly_rate=100, daily_rate=1000, current_km=2000, last_service_km=1500),
            Vehicle(name='Hyundai Creta', type='car', hourly_rate=300, daily_rate=2500, current_km=8000, last_service_km=7500),
            Vehicle(name='Activa 6G', type='bike', hourly_rate=50, daily_rate=400, current_km=1200, last_service_km=1100)
        ]
        db.session.add_all(vehicles)
        db.session.commit()
        print("Database seeded successfully!")

if __name__ == '__main__':
    seed_data()
